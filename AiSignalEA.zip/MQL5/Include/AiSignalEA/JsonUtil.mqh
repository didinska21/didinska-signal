//+------------------------------------------------------------------+
//| JsonUtil.mqh                                                       |
//| Parser JSON MINIMAL & SENGAJA TERBATAS -- BUKAN parser JSON umum   |
//| yang menangani nested object/array. Cukup buat ekstrak value dari  |
//| 1 object JSON FLAT (key: string/number di level teratas), yang     |
//| memang persis bentuk yang diminta dari Groq (lihat AiAnalyst.mqh,  |
//| response_format json_schema). Kalau butuh JSON umum, pakai library |
//| pihak ketiga (mis. JAson.mqh) -- di sini sengaja tidak, biar kode  |
//| gampang diaudit tanpa dependency luar.                              |
//|                                                                    |
//| Batasan yang disadari (cukup buat kasus penggunaan ini):           |
//| - Unescape cuma menangani \" \\ \n \t (paling umum muncul di teks  |
//|   reasoning AI). Backslash literal ganda yang diikuti huruf lain    |
//|   secara kebetulan bisa salah baca -- praktiknya nyaris tidak      |
//|   pernah muncul di teks analisa AI.                                |
//+------------------------------------------------------------------+
#property strict

//--- Ambil value STRING dari key di level teratas object JSON.
//--- Return "" kalau key tidak ketemu atau bukan string.
string JsonGetString(const string json, const string key)
{
   int keyPos = StringFind(json, "\"" + key + "\"");
   if (keyPos < 0) return "";

   int colonPos = StringFind(json, ":", keyPos);
   if (colonPos < 0) return "";

   int firstQuote = StringFind(json, "\"", colonPos);
   if (firstQuote < 0) return "";
   firstQuote++; // geser ke karakter SETELAH tanda kutip pembuka

   int len = StringLen(json);
   int cursor = firstQuote;
   while (cursor < len)
   {
      ushort ch = StringGetCharacter(json, cursor);
      if (ch == '\\') { cursor += 2; continue; } // lompatin 1 escape sequence (2 karakter: \ + X)
      if (ch == '"') break;
      cursor++;
   }

   string raw = StringSubstr(json, firstQuote, cursor - firstQuote);
   StringReplace(raw, "\\n", "\n");
   StringReplace(raw, "\\t", "\t");
   StringReplace(raw, "\\\"", "\"");
   StringReplace(raw, "\\\\", "\\");
   return raw;
}

//--- Ambil value NUMBER (int/double) dari key di level teratas object
//--- JSON. Return 0.0 kalau key tidak ketemu.
double JsonGetDouble(const string json, const string key)
{
   int keyPos = StringFind(json, "\"" + key + "\"");
   if (keyPos < 0) return 0.0;

   int colonPos = StringFind(json, ":", keyPos);
   if (colonPos < 0) return 0.0;

   int len = StringLen(json);
   int cursor = colonPos + 1;

   // Lewatin whitespace & tanda kutip (jaga-jaga kalau angkanya kebetulan
   // dikirim sebagai string, mis. "entry":"4584.14")
   while (cursor < len)
   {
      ushort ch = StringGetCharacter(json, cursor);
      if (ch == ' ' || ch == '\n' || ch == '\t' || ch == '\r' || ch == '"') { cursor++; continue; }
      break;
   }

   int start = cursor;
   while (cursor < len)
   {
      ushort ch = StringGetCharacter(json, cursor);
      bool isNumericChar = (ch >= '0' && ch <= '9') || ch == '-' || ch == '+' || ch == '.' || ch == 'e' || ch == 'E';
      if (!isNumericChar) break;
      cursor++;
   }

   string numStr = StringSubstr(json, start, cursor - start);
   return StringToDouble(numStr);
}

//--- Ambil value INTEGER (pembulatan dari double) dari key JSON.
int JsonGetInt(const string json, const string key)
{
   return (int)MathRound(JsonGetDouble(json, key));
}
