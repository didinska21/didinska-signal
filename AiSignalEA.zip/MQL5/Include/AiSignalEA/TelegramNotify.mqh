//+------------------------------------------------------------------+
//| TelegramNotify.mqh                                                 |
//| Notifikasi Telegram SATU ARAH (EA -> Telegram saja). EA ini TIDAK  |
//| menerima command/tombol balik dari Telegram -- kontrol EA (mulai, |
//| berhenti, ganti strategi/parameter) dilakukan lewat Input          |
//| Parameter EA di MT5, bukan lewat chat. Sesuai keputusan yang sudah |
//| dikonfirmasi.                                                      |
//+------------------------------------------------------------------+
#property strict
#include <AiSignalEA/Common.mqh>

//--- Kirim 1 pesan teks ke Telegram. `parseHtml=true` pakai parse_mode
//--- HTML (izinkan <b>, <i> dst di teks). Best-effort: kalau gagal
//--- kirim, cuma di-Print ke log EA, TIDAK menghentikan jalannya EA.
void TelegramSend(const string botToken, const string chatId, const string text, const bool parseHtml = true)
{
   if (StringLen(botToken) == 0 || StringLen(chatId) == 0)
   {
      Print("⚠️ TelegramSend dilewati: bot token / chat ID kosong di Input Parameter.");
      return;
   }

   string url = "https://api.telegram.org/bot" + botToken + "/sendMessage";
   string body = "{\"chat_id\":\"" + chatId + "\",\"text\":\"" + JsonEscape(text) + "\"" +
                 (parseHtml ? ",\"parse_mode\":\"HTML\"" : "") + "}";

   string response;
   int status = HttpPostJson(url, "", body, 10000, response);

   if (status != 200)
      PrintFormat("⚠️ Gagal kirim notifikasi Telegram (HTTP %d): %s", status, response);
}
