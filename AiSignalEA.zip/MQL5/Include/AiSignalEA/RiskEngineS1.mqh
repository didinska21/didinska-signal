//+------------------------------------------------------------------+
//| RiskEngineS1.mqh                                                    |
//| Strategi 1 NATIVE: 1 posisi, native SL/TP (dari AI, dikirim persis |
//| sebagai bagian order -- jaring pengaman broker), lot dihitung      |
//| dinamis tiap entry supaya risiko ke SL asli ~ InpRiskSlPercent%   |
//| balance. Guardrail: 1 posisi terbuka, limit trade/hari, circuit    |
//| breaker rugi harian. Force-close TAMBAHAN kalau floating %         |
//| kena duluan sebelum harga sampai native SL/TP.                     |
//|                                                                    |
//| PENINGKATAN dari versi Telegram/Python lama: contract size, lot    |
//| step, dan lot minimum di sini diambil LANGSUNG dari broker         |
//| (SymbolInfoDouble) -- bukan asumsi tetap "100 oz/lot" seperti      |
//| versi lama yang tidak bisa query broker secara langsung.           |
//+------------------------------------------------------------------+
#property strict
#include <Trade/Trade.mqh>
#include <AiSignalEA/Common.mqh>
#include <AiSignalEA/TelegramNotify.mqh>

//--- State harian S1, disimpan di memory EA (reset kalau EA di-restart --
//--- ini beda kecil dari versi lama yang reset persis jam 00:00 UTC;
//--- di sini pakai waktu SERVER broker, dan reset paling telat pas EA
//--- jalan lagi kalau kebetulan restart pas hari baru).
static datetime g_s1LastResetDay = 0;
static int      g_s1TradesToday = 0;
static double   g_s1DayStartEquity = 0.0;

void S1_CheckDailyReset()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   dt.hour = 0; dt.min = 0; dt.sec = 0;
   datetime todayMidnight = StructToTime(dt);

   if (todayMidnight != g_s1LastResetDay)
   {
      g_s1LastResetDay = todayMidnight;
      g_s1TradesToday = 0;
      g_s1DayStartEquity = AccountInfoDouble(ACCOUNT_EQUITY);
      PrintFormat("📅 [S1] Reset harian: tradesToday=0, dayStartEquity=%s", FormatMoney(g_s1DayStartEquity));
   }
}

//--- Cari posisi terbuka dgn magic number S1 di simbol ini. Return
//--- true kalau ketemu (S1 cuma boleh 1).
bool S1_HasOpenPosition(const int magicNumber)
{
   int total = PositionsTotal();
   for (int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if (ticket == 0) continue;
      if (!PositionSelectByTicket(ticket)) continue;
      if (PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if (PositionGetInteger(POSITION_MAGIC) == magicNumber) return true;
   }
   return false;
}

//--- Guardrail S1: 1 posisi max, limit trade/hari, circuit breaker rugi
//--- harian. TIDAK ada efek samping (tidak increment counter) -- itu
//--- dilakukan terpisah di S1_ExecuteTrade SETELAH order beneran sukses.
bool S1_CheckGuardrails(const int magicNumber, const int maxTradesPerDay, const double maxDailyLossPct, string &reasonOut)
{
   S1_CheckDailyReset();

   if (S1_HasOpenPosition(magicNumber))
   {
      reasonOut = "Masih ada 1 posisi S1 terbuka.";
      return false;
   }

   if (g_s1TradesToday >= maxTradesPerDay)
   {
      reasonOut = StringFormat("Sudah %d/%d trade hari ini (limit harian).", g_s1TradesToday, maxTradesPerDay);
      return false;
   }

   if (g_s1DayStartEquity > 0.0)
   {
      double equity = AccountInfoDouble(ACCOUNT_EQUITY);
      double lossPct = ((g_s1DayStartEquity - equity) / g_s1DayStartEquity) * 100.0;
      if (lossPct >= maxDailyLossPct)
      {
         reasonOut = StringFormat("Circuit breaker aktif: rugi %.2f%% hari ini (limit %.2f%%).", lossPct, maxDailyLossPct);
         return false;
      }
   }

   return true;
}

//--- Hitung lot supaya KALAU harga sampai kena SL, kerugian ~ riskPct%
//--- dari balance saat ini. Dibulatkan KE BAWAH ke kelipatan lot step
//--- broker -- lebih aman risiko sedikit di bawah target daripada lebih.
//--- Return 0.0 kalau hasil hitungan di bawah lot minimum broker (artinya
//--- JANGAN eksekusi, modal kemungkinan kekecilan buat jarak SL ini).
double S1_CalcLot(const double riskPct, const double entryPrice, const double slPrice)
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   double slDistance = MathAbs(entryPrice - slPrice);
   if (balance <= 0.0 || slDistance <= 0.0) return 0.0;

   double contractSize = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_CONTRACT_SIZE);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   double minLot = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   if (contractSize <= 0.0 || lotStep <= 0.0) return 0.0;

   double riskAmount = (riskPct / 100.0) * balance;
   double rawLot = riskAmount / (slDistance * contractSize);
   double steppedLot = MathFloor(rawLot / lotStep) * lotStep;
   steppedLot = NormalizeDouble(steppedLot, 2);

   if (steppedLot < minLot) return 0.0;
   return steppedLot;
}

//--- Eksekusi order S1: native SL/TP dari AI, lot dinamis. Kirim
//--- notifikasi Telegram sendiri (sukses/gagal/dibatalkan).
void S1_ExecuteTrade(const string decision, const double entryPrice, const double slPrice, const double tpPrice,
                      const int magicNumber, const double riskPct,
                      const string telegramToken, const string telegramChatId)
{
   double lot = S1_CalcLot(riskPct, entryPrice, slPrice);
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);

   if (lot <= 0.0)
   {
      TelegramSend(telegramToken, telegramChatId,
         StringFormat("🧭⛔ Sinyal %s (Strategi 1) TIDAK dieksekusi: lot hasil hitung risiko %.1f%% (balance $%s) di bawah lot minimum broker. Modal kemungkinan terlalu kecil untuk jarak SL sinyal ini.",
            decision, riskPct, FormatMoney(balance)));
      return;
   }

   CTrade trade;
   trade.SetExpertMagicNumber(magicNumber);
   trade.SetDeviationInPoints(20);
   trade.SetTypeFillingBySymbol(_Symbol);

   bool sent = false;
   if (decision == "BUY")
      sent = trade.Buy(lot, _Symbol, 0.0, slPrice, tpPrice, "AiSignalEA-S1");
   else if (decision == "SELL")
      sent = trade.Sell(lot, _Symbol, 0.0, slPrice, tpPrice, "AiSignalEA-S1");
   else
      return; // WAIT -- tidak ada yang perlu dieksekusi

   uint retcode = trade.ResultRetcode();
   if (!sent || retcode != TRADE_RETCODE_DONE)
   {
      PrintFormat("❌ [S1] Order gagal, retcode=%d (%s)", retcode, DescribeRetcode((int)retcode));
      TelegramSend(telegramToken, telegramChatId,
         StringFormat("🧭❌ Order %s (Strategi 1) GAGAL: %s (retcode %d)", decision, DescribeRetcode((int)retcode), retcode));
      return;
   }

   g_s1TradesToday++; // increment SETELAH sukses (beda dari versi lama yang increment sebelum -- di sini lebih aman karena guardrail & eksekusi jadi 1 alur sinkron, tidak ada celah race antar-request seperti arsitektur Worker)

   double riskUsd = (riskPct / 100.0) * balance;
   PrintFormat("✅ [S1] Order %s sukses. Ticket=%d, lot=%s, fill=%s", decision, (int)trade.ResultOrder(), DoubleToString(lot, 2), DoubleToString(trade.ResultPrice(), _Digits));
   TelegramSend(telegramToken, telegramChatId,
      StringFormat("🧭🔗 Order %s (Strategi 1) sukses.\nTicket: %d | Lot: %s (~%.1f%% risiko = $%s dari balance $%s)\nEntry fill: %s | SL: %s | TP: %s",
         decision, (int)trade.ResultOrder(), DoubleToString(lot, 2), riskPct, FormatMoney(riskUsd), FormatMoney(balance),
         DoubleToString(trade.ResultPrice(), _Digits), DoubleToString(slPrice, _Digits), DoubleToString(tpPrice, _Digits)));
}

//--- Pantau floating % dari balance, TAMBAHAN paralel ke native SL/TP.
//--- Ditutup duluan kalau floating kena ambang % SEBELUM harga sampai
//--- ke level SL/TP native.
void S1_CheckForceClose(const int magicNumber, const double forceCloseProfitPct, const double forceCloseLossPct,
                         const string telegramToken, const string telegramChatId)
{
   double balance = AccountInfoDouble(ACCOUNT_BALANCE);
   if (balance <= 0.0) return;

   int total = PositionsTotal();
   for (int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if (ticket == 0) continue;
      if (!PositionSelectByTicket(ticket)) continue;
      if (PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if (PositionGetInteger(POSITION_MAGIC) != magicNumber) continue;

      double profit = PositionGetDouble(POSITION_PROFIT);
      double profitPct = (profit / balance) * 100.0;

      bool tpHit = profitPct >= forceCloseProfitPct;
      bool slHit = profitPct <= -forceCloseLossPct;
      if (!tpHit && !slHit) continue;

      CTrade trade;
      trade.SetExpertMagicNumber(magicNumber);
      trade.SetDeviationInPoints(20);

      if (trade.PositionClose(ticket))
      {
         string label = tpHit ? "TP (profit lock)" : "SL (cut loss)";
         PrintFormat("🔒 [S1] Force-close ticket %d sukses -- %s di floating %.2f%% balance.", (int)ticket, label, profitPct);
         TelegramSend(telegramToken, telegramChatId,
            StringFormat("%s Strategi 1 -- %s\nTicket: %d | Floating saat ditutup: %.2f%% dari balance ($%s)\n<i>Ditutup otomatis karena floating sudah mencapai ambang %%, sebelum harga sempat sampai ke level SL/TP asli.</i>",
               tpHit ? "🔒✅" : "🔒❌", label, (int)ticket, profitPct, FormatMoney(profit)));
      }
      else
      {
         uint retcode = trade.ResultRetcode();
         PrintFormat("❌ [S1] Force-close ticket %d GAGAL, retcode=%d (%s). Posisi tetap terbuka -- native SL/TP masih jadi jaring pengaman.", (int)ticket, retcode, DescribeRetcode((int)retcode));
      }
   }
}
