//+------------------------------------------------------------------+
//| AiAnalyst.mqh                                                      |
//| Ambil data pasar NATIVE (CopyRates/iMA/iATR -- tidak ada panggilan |
//| keluar sama sekali di tahap ini, beda dari sistem Telegram lama    |
//| yang harus relay data lewat bridge), susun 1 PROMPT GABUNGAN       |
//| (gantiin 10 panggilan AI terpisah), kirim ke Groq dengan           |
//| response_format json_schema (strict) biar jawabannya SELALU JSON   |
//| valid -- menghindari SELURUH kelas bug parsing teks-bebas yang     |
//| pernah terjadi di versi Telegram bot (koma-desimal dkk).            |
//|                                                                    |
//| CATATAN SOAL KEDALAMAN ANALISA:                                    |
//| Versi ini SENGAJA lebih ringkas dibanding sistem 10-AI-spesialis   |
//| yang lama (yang masing-masing motret SMC/Fibonacci/likuiditas/dst  |
//| lewat modul terpisah). Di sini, 6 timeframe diringkas jadi SMA20,  |
//| ATR14, dan rentang tertinggi/terendah 20 bar terakhir, lalu AI     |
//| yang menyimpulkan langsung dari situ. Ini trade-off sadar demi     |
//| kesederhanaan & keandalan di MQL5 (tidak reimplement algoritma     |
//| SMC/Fibo dari nol) -- kalau ternyata kurang tajam, timeframe/      |
//| indikator tambahan bisa disisipkan di BuildTimeframeSummary().     |
//+------------------------------------------------------------------+
#property strict
#include <AiSignalEA/Common.mqh>
#include <AiSignalEA/JsonUtil.mqh>

//--- Hasil 1 siklus analisa AI, dikembalikan sebagai struct biar rapi.
struct SAiDecision
{
   bool   success;      // false kalau HTTP gagal / JSON tidak valid -- JANGAN eksekusi apa pun kalau false
   string decision;     // "BUY" | "SELL" | "WAIT"
   double entry;        // harga acuan AI (buat referensi/native SL-TP, S1 saja)
   double sl;
   double tp;
   double confidence;   // 0-100, dari AI
   string reasoning;    // ringkasan alasan, buat notifikasi Telegram
   string rawError;     // detail error kalau success == false
};

//--- Ringkasan 1 timeframe: SMA20, ATR14, rentang 20 bar terakhir, harga
//--- penutupan terakhir, dan posisi harga relatif ke SMA.
string BuildTimeframeSummary(const string symbol, const ENUM_TIMEFRAMES tf, const string label)
{
   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   int copied = CopyRates(symbol, tf, 0, 20, rates);
   if (copied < 5)
      return StringFormat("%s: data candle tidak cukup (cuma %d bar tersedia)\n", label, copied);

   double lastClose = rates[0].close;
   double highest = rates[0].high, lowest = rates[0].low;
   for (int i = 1; i < copied; i++)
   {
      if (rates[i].high > highest) highest = rates[i].high;
      if (rates[i].low < lowest) lowest = rates[i].low;
   }

   int maHandle = iMA(symbol, tf, 20, 0, MODE_SMA, PRICE_CLOSE);
   double sma = 0.0;
   if (maHandle != INVALID_HANDLE)
   {
      double maBuf[];
      ArraySetAsSeries(maBuf, true);
      if (CopyBuffer(maHandle, 0, 0, 1, maBuf) > 0) sma = maBuf[0];
      IndicatorRelease(maHandle);
   }

   int atrHandle = iATR(symbol, tf, 14);
   double atr = 0.0;
   if (atrHandle != INVALID_HANDLE)
   {
      double atrBuf[];
      ArraySetAsSeries(atrBuf, true);
      if (CopyBuffer(atrHandle, 0, 0, 1, atrBuf) > 0) atr = atrBuf[0];
      IndicatorRelease(atrHandle);
   }

   string posisi = (sma > 0.0) ? (lastClose > sma ? "DI ATAS SMA20 (bias naik)" : "DI BAWAH SMA20 (bias turun)") : "N/A";

   return StringFormat(
      "%s: Close=%s | SMA20=%s (%s) | ATR14=%s | Range 20bar: %s - %s\n",
      label,
      DoubleToString(lastClose, _Digits),
      DoubleToString(sma, _Digits),
      posisi,
      DoubleToString(atr, _Digits),
      DoubleToString(lowest, _Digits),
      DoubleToString(highest, _Digits)
   );
}

//--- Susun 1 prompt gabungan dari 6 timeframe (M1, M5, M15, H1, H4, D1) +
//--- konteks mode trading yang dipilih user lewat Input Parameter.
string BuildPrompt(const string symbol, const string tradeModeLabel, const double currentBid, const double currentAsk)
{
   string data = "";
   data += BuildTimeframeSummary(symbol, PERIOD_M1, "M1");
   data += BuildTimeframeSummary(symbol, PERIOD_M5, "M5");
   data += BuildTimeframeSummary(symbol, PERIOD_M15, "M15");
   data += BuildTimeframeSummary(symbol, PERIOD_H1, "H1");
   data += BuildTimeframeSummary(symbol, PERIOD_H4, "H4");
   data += BuildTimeframeSummary(symbol, PERIOD_D1, "D1");

   string prompt =
      "Kamu adalah sintesis dari 10 analis trading spesialis (trend, momentum, volatilitas, "
      "support/resistance, struktur pasar, likuiditas, Fibonacci, makro, sentimen, dan manajemen risiko) "
      "yang menganalisis " + symbol + " untuk mode trading: " + tradeModeLabel + ".\n\n" +
      "DATA PASAR (multi-timeframe, dari native MT5, real-time):\n" + data + "\n" +
      "Harga saat ini: Bid=" + DoubleToString(currentBid, _Digits) + " Ask=" + DoubleToString(currentAsk, _Digits) + "\n\n" +
      "Berdasarkan data di atas, berikan SATU keputusan trading akhir. Kalau sinyal tidak cukup jelas/meyakinkan, "
      "pilih WAIT (jangan paksakan BUY/SELL). Kalau BUY/SELL, tentukan Entry (dekat harga saat ini), "
      "Stop-Loss (berdasarkan ATR & struktur harga terdekat), dan Take-Profit (rasio risk:reward minimal 1:1.5). "
      "Field 'confidence' adalah keyakinanmu 0-100. Field 'reasoning' singkat (maks 3 kalimat, Bahasa Indonesia).";

   return prompt;
}

//--- Panggil Groq Chat Completions API dengan response_format json_schema
//--- (strict), lalu parse hasilnya. TIDAK ADA fallback ke teks bebas --
//--- kalau schema gagal dipatuhi model, success=false dan JANGAN
//--- eksekusi apa pun (lebih aman diam daripada salah tafsir).
SAiDecision RequestAiDecision(const string apiKey, const string model, const string symbol, const string tradeModeLabel)
{
   SAiDecision result;
   result.success = false;
   result.decision = "WAIT";
   result.entry = 0.0;
   result.sl = 0.0;
   result.tp = 0.0;
   result.confidence = 0.0;
   result.reasoning = "";
   result.rawError = "";

   MqlTick tick;
   if (!SymbolInfoTick(symbol, tick))
   {
      result.rawError = "Gagal ambil tick harga terkini dari terminal.";
      return result;
   }

   string prompt = BuildPrompt(symbol, tradeModeLabel, tick.bid, tick.ask);

   string schema =
      "{\"type\":\"json_schema\",\"json_schema\":{\"name\":\"trading_decision\",\"strict\":true,\"schema\":{"
      "\"type\":\"object\",\"properties\":{"
      "\"decision\":{\"type\":\"string\",\"enum\":[\"BUY\",\"SELL\",\"WAIT\"]},"
      "\"entry\":{\"type\":\"number\"},"
      "\"sl\":{\"type\":\"number\"},"
      "\"tp\":{\"type\":\"number\"},"
      "\"confidence\":{\"type\":\"number\"},"
      "\"reasoning\":{\"type\":\"string\"}"
      "},\"required\":[\"decision\",\"entry\",\"sl\",\"tp\",\"confidence\",\"reasoning\"],"
      "\"additionalProperties\":false}}}";

   string body =
      "{\"model\":\"" + model + "\","
      "\"temperature\":0.3,"
      "\"max_tokens\":900,"
      "\"messages\":[{\"role\":\"user\",\"content\":\"" + JsonEscape(prompt) + "\"}],"
      "\"response_format\":" + schema +
      "}";

   string response;
   int status = HttpPostJson("https://api.groq.com/openai/v1/chat/completions", "Authorization: Bearer " + apiKey + "\r\n", body, 30000, response);

   if (status != 200)
   {
      result.rawError = StringFormat("Groq API HTTP %d: %s", status, response);
      return result;
   }

   string content = JsonGetString(response, "content");
   if (StringLen(content) == 0)
   {
      result.rawError = "Response Groq tidak mengandung field 'content' (cek raw response: " + response + ")";
      return result;
   }

   string decision = JsonGetString(content, "decision");
   if (decision != "BUY" && decision != "SELL" && decision != "WAIT")
   {
      result.rawError = "Field 'decision' tidak valid/kosong dari AI: " + content;
      return result;
   }

   result.success = true;
   result.decision = decision;
   result.entry = JsonGetDouble(content, "entry");
   result.sl = JsonGetDouble(content, "sl");
   result.tp = JsonGetDouble(content, "tp");
   result.confidence = JsonGetDouble(content, "confidence");
   result.reasoning = JsonGetString(content, "reasoning");
   return result;
}
