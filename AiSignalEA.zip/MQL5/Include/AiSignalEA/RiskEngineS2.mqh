//+------------------------------------------------------------------+
//| RiskEngineS2.mqh                                                    |
//| Strategi 2 NATIVE: sampai InpMaxLayers posisi INDEPENDEN sekaligus |
//| (magic number beda dari S1), market order MURNI TANPA native       |
//| SL/TP sama sekali (keputusan sadar, sama seperti versi Telegram    |
//| lama) -- lot FIXED, TIDAK ADA limit trade/hari atau circuit        |
//| breaker. Tiap layer auto-close SENDIRI (independen, tidak saling   |
//| terkait) di floating FLAT dollar (+InpLayerTpUsd / -InpLayerSlUsd).|
//|                                                                    |
//| ⚠️ KARENA TANPA native SL/TP, layer yang terbuka 100% bergantung   |
//| EA ini tetap jalan di terminal (chart tidak di-detach, terminal    |
//| tidak mati/disconnect). Kalau EA berhenti, TIDAK ADA jaring        |
//| pengaman apa pun di level broker sampai EA jalan lagi.              |
//+------------------------------------------------------------------+
#property strict
#include <Trade/Trade.mqh>
#include <AiSignalEA/Common.mqh>
#include <AiSignalEA/TelegramNotify.mqh>

//--- Hitung berapa layer S2 yang lagi terbuka di simbol ini.
int S2_CountOpenLayers(const int magicNumber)
{
   int count = 0;
   int total = PositionsTotal();
   for (int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if (ticket == 0) continue;
      if (!PositionSelectByTicket(ticket)) continue;
      if (PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if (PositionGetInteger(POSITION_MAGIC) == magicNumber) count++;
   }
   return count;
}

//--- Guardrail S2: SATU-SATUNYA syarat adalah jumlah layer < maxLayers.
//--- TIDAK ADA limit trade/hari atau circuit breaker rugi harian, sesuai
//--- keputusan eksplisit -- murni TP $/SL $ flat per layer.
bool S2_CheckGuardrails(const int magicNumber, const int maxLayers, string &reasonOut)
{
   int openCount = S2_CountOpenLayers(magicNumber);
   if (openCount >= maxLayers)
   {
      reasonOut = StringFormat("Sudah %d/%d layer terbuka.", openCount, maxLayers);
      return false;
   }
   return true;
}

//--- Eksekusi 1 layer baru: market order MURNI, lot fixed, TANPA SL/TP.
void S2_ExecuteLayer(const string decision, const double lot, const int magicNumber, const int maxLayers,
                      const string telegramToken, const string telegramChatId)
{
   CTrade trade;
   trade.SetExpertMagicNumber(magicNumber);
   trade.SetDeviationInPoints(20);
   trade.SetTypeFillingBySymbol(_Symbol);

   bool sent = false;
   // sl=0, tp=0 -- SENGAJA tanpa native SL/TP (lihat catatan di atas file ini)
   if (decision == "BUY")
      sent = trade.Buy(lot, _Symbol, 0.0, 0.0, 0.0, "AiSignalEA-S2-layer");
   else if (decision == "SELL")
      sent = trade.Sell(lot, _Symbol, 0.0, 0.0, 0.0, "AiSignalEA-S2-layer");
   else
      return; // WAIT

   uint retcode = trade.ResultRetcode();
   if (!sent || retcode != TRADE_RETCODE_DONE)
   {
      PrintFormat("❌ [S2] Order layer gagal, retcode=%d (%s)", retcode, DescribeRetcode((int)retcode));
      TelegramSend(telegramToken, telegramChatId,
         StringFormat("🧱❌ Layer %s (Strategi 2) GAGAL: %s (retcode %d)", decision, DescribeRetcode((int)retcode), retcode));
      return;
   }

   int newCount = S2_CountOpenLayers(magicNumber);
   PrintFormat("✅ [S2] Layer %s sukses. Ticket=%d, lot=%s, fill=%s", decision, (int)trade.ResultOrder(), DoubleToString(lot, 2), DoubleToString(trade.ResultPrice(), _Digits));
   TelegramSend(telegramToken, telegramChatId,
      StringFormat("🧱🔗 Layer %s (Strategi 2) sukses.\nTicket: %d | Lot: %s (fixed)\nFill: %s | Market order murni, tanpa native SL/TP.\nLayer aktif: %d/%d",
         decision, (int)trade.ResultOrder(), DoubleToString(lot, 2), DoubleToString(trade.ResultPrice(), _Digits), newCount, maxLayers));
}

//--- Pantau floating $ FLAT tiap layer, SECARA INDEPENDEN satu sama
//--- lain. Ini SATU-SATUNYA yang bisa menutup layer (tidak ada native
//--- SL/TP di order-nya).
void S2_CheckForceClose(const int magicNumber, const double layerTpUsd, const double layerSlUsd,
                         const string telegramToken, const string telegramChatId)
{
   int total = PositionsTotal();
   for (int i = total - 1; i >= 0; i--)
   {
      ulong ticket = PositionGetTicket(i);
      if (ticket == 0) continue;
      if (!PositionSelectByTicket(ticket)) continue;
      if (PositionGetString(POSITION_SYMBOL) != _Symbol) continue;
      if (PositionGetInteger(POSITION_MAGIC) != magicNumber) continue;

      double profit = PositionGetDouble(POSITION_PROFIT);
      bool tpHit = profit >= layerTpUsd;
      bool slHit = profit <= -layerSlUsd;
      if (!tpHit && !slHit) continue;

      CTrade trade;
      trade.SetExpertMagicNumber(magicNumber);
      trade.SetDeviationInPoints(20);

      if (trade.PositionClose(ticket))
      {
         string label = tpHit ? "TP layer (+$)" : "SL layer (-$)";
         PrintFormat("🧱 [S2] Force-close ticket %d sukses -- %s, floating $%s.", (int)ticket, label, FormatMoney(profit));
         TelegramSend(telegramToken, telegramChatId,
            StringFormat("%s Strategi 2 -- %s\nTicket: %d | Floating saat ditutup: $%s\n<i>Market order tanpa native SL/TP, jadi ini satu-satunya yang menutup layer ini.</i>",
               tpHit ? "🧱✅" : "🧱❌", label, (int)ticket, FormatMoney(profit)));
      }
      else
      {
         uint retcode = trade.ResultRetcode();
         PrintFormat("❌ [S2] Force-close ticket %d GAGAL, retcode=%d (%s). Posisi TETAP TERBUKA -- TANPA native SL/TP, akan dicoba lagi siklus berikutnya.", (int)ticket, retcode, DescribeRetcode((int)retcode));
      }
   }
}
