//+------------------------------------------------------------------+
//| Common.mqh                                                        |
//| Konstanta, enum, dan helper yang dipakai bareng di seluruh modul  |
//| AiSignalEA (Strategi 1 & Strategi 2). Standalone -- TIDAK          |
//| bergantung ke Cloudflare Worker/Python bridge sama sekali; semua  |
//| panggilan keluar (Groq, Telegram) lewat WebRequest() native MQL5. |
//|                                                                    |
//| PENTING SEBELUM COMPILE/RUN:                                      |
//| Tambahkan 2 URL ini ke Tools > Options > Expert Advisors >        |
//| "Allow WebRequest for listed URL":                                |
//|   https://api.groq.com                                            |
//|   https://api.telegram.org                                        |
//| Kalau lupa, WebRequest() akan gagal dengan error 4060.             |
//+------------------------------------------------------------------+
#property strict

//--- Strategi yang didukung EA ini. 1 instance EA = 1 strategi (pilih
//--- lewat input InpStrategy). Mau jalanin dua-duanya bersamaan? Attach
//--- EA ini 2x ke 2 window chart XAUUSD berbeda, masing-masing pilih
//--- strategi & magic number yang beda (lihat AiSignalEA.mq5).
enum ENUM_AI_STRATEGY
{
   STRATEGY_S1_SINGLE = 0,   // Strategi 1: 1 posisi, native SL/TP, lot dinamis
   STRATEGY_S2_LAYERS = 1    // Strategi 2: sampai N layer independen, market order murni
};

//--- Kode & pesan MT5 yang paling sering muncul saat order gagal. Daftar
//--- ini SENGAJA tidak lengkap (cuma yang paling relevan buat XAUUSD demo
//--- trading) -- kalau ketemu kode lain, fallback ke pesan generik.
string DescribeRetcode(const int code)
{
   switch (code)
   {
      case 10004: return "Requote";
      case 10006: return "Request ditolak";
      case 10007: return "Request dibatalkan oleh trader";
      case 10008: return "Order sudah ditempatkan";
      case 10009: return "Request selesai (TRADE_RETCODE_DONE)";
      case 10013: return "Request tidak valid";
      case 10014: return "Volume tidak valid";
      case 10015: return "Harga tidak valid";
      case 10016: return "SL/TP tidak valid (kemungkinan terlalu dekat dari harga saat ini)";
      case 10017: return "Trading dinonaktifkan";
      case 10018: return "PASAR SEDANG TUTUP (market closed) -- coba lagi saat jam pasar buka";
      case 10019: return "Dana tidak cukup (margin tidak cukup)";
      case 10020: return "Harga berubah (price changed)";
      case 10021: return "Tidak ada harga (no quotes) untuk eksekusi";
      case 10025: return "Tidak ada perubahan di request";
      case 10026: return "Server autotrading dinonaktifkan";
      case 10027: return "Autotrading dinonaktifkan di terminal client (tombol AutoTrading OFF)";
      case 10030: return "Filling mode tidak didukung broker ini";
      case 10031: return "Tidak ada koneksi ke server trading";
      default:    return StringFormat("Retcode %d tidak dikenal (cek dokumentasi MQL5 TRADE_RETCODE)", code);
   }
}

//--- Escape string biar aman ditaruh sebagai value JSON (dipakai buat
//--- prompt yang berisi data candle & instruksi, sebelum dikirim ke Groq).
string JsonEscape(string text)
{
   StringReplace(text, "\\", "\\\\"); // WAJIB paling awal, sebelum escape lain ditambahkan
   StringReplace(text, "\"", "\\\"");
   StringReplace(text, "\r\n", "\\n");
   StringReplace(text, "\n", "\\n");
   StringReplace(text, "\r", "\\n");
   StringReplace(text, "\t", "\\t");
   return text;
}

//+------------------------------------------------------------------+
//| Kirim POST HTTP dengan body JSON via WebRequest() native MQL5.    |
//| Return: HTTP status code (200, 401, dst), atau -1 kalau           |
//| WebRequest sendiri gagal (paling sering: URL belum di-whitelist,  |
//| lihat catatan di atas file ini -- atau tidak ada koneksi          |
//| internet). Response body (apa pun statusnya) dikembalikan lewat   |
//| parameter `responseOut`.                                          |
//+------------------------------------------------------------------+
int HttpPostJson(const string url, const string extraHeaders, const string jsonBody, const int timeoutMs, string &responseOut)
{
   responseOut = "";
   string headers = "Content-Type: application/json\r\n" + extraHeaders;

   char postData[];
   int written = StringToCharArray(jsonBody, postData, 0, WHOLE_ARRAY, CP_UTF8);
   if (written > 0) ArrayResize(postData, written - 1); // buang null-terminator, WAJIB

   char resultData[];
   string resultHeaders;

   ResetLastError();
   int status = WebRequest("POST", url, headers, timeoutMs, postData, resultData, resultHeaders);

   if (status == -1)
   {
      int err = GetLastError();
      if (err == 4060)
         PrintFormat("❌ WebRequest gagal (error 4060): URL '%s' belum di-whitelist. Tambahkan di Tools > Options > Expert Advisors > \"Allow WebRequest for listed URL\".", url);
      else
         PrintFormat("❌ WebRequest gagal ke '%s', error MQL5=%d", url, err);
      return -1;
   }

   responseOut = CharArrayToString(resultData, 0, ArraySize(resultData), CP_UTF8);
   return status;
}

//--- Format angka dolar/persen buat notifikasi, konsisten 2 desimal.
string FormatMoney(const double value)
{
   return DoubleToString(value, 2);
}
