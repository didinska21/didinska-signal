//+------------------------------------------------------------------+
//|                                                    AiSignalEA.mq5  |
//| EA trading XAUUSD berbasis AI (Groq), STANDALONE -- tidak          |
//| bergantung ke Cloudflare Worker/Python bridge/Telegram bot sama    |
//| sekali. Replikasi dari sistem sinyal Telegram (didinska-signal),   |
//| dibangun ulang native di MQL5:                                     |
//|   - Data pasar: native (CopyRates/iMA/iATR), tanpa panggilan luar. |
//|   - Analisa: 1 panggilan API gabungan ke Groq (bukan 10 berurutan  |
//|     seperti versi lama) -- menghindari WebRequest blocking lama.   |
//|   - Jawaban AI: JSON terstruktur (response_format json_schema,     |
//|     strict) -- menghindari bug parsing teks-bebas versi lama.      |
//|   - Telegram: NOTIFIKASI SATU ARAH saja (EA -> Telegram). Kontrol  |
//|     EA (mulai/berhenti/pilih strategi/parameter) lewat Input       |
//|     Parameter EA ini, BUKAN lewat command/tombol Telegram.         |
//|   - Strategi 1 & Strategi 2: pilih salah satu lewat InpStrategy.   |
//|     Mau dua-duanya jalan bersamaan? Attach EA ini 2x ke 2 window   |
//|     chart XAUUSD berbeda, masing-masing pilih strategi berbeda.    |
//|                                                                    |
//| ⚠️ SEBELUM DIPAKAI:                                                |
//| 1. Tools > Options > Expert Advisors > centang "Allow WebRequest   |
//|    for listed URL", tambahkan:                                     |
//|      https://api.groq.com                                          |
//|      https://api.telegram.org                                      |
//| 2. Isi InpGroqApiKey & (opsional) InpTelegramBotToken/ChatId di     |
//|    Input Parameter sebelum attach ke chart.                        |
//| 3. TES DI AKUN DEMO DULU. InpRequireDemoAccount=true secara         |
//|    default -- JANGAN dimatikan sampai kamu benar-benar yakin.       |
//|                                                                    |
//| ⚠️ KODE INI BELUM PERNAH DI-COMPILE (Claude tidak punya akses ke    |
//| compiler MT5) -- kemungkinan ada typo/error kecil yang baru        |
//| ketauan pas kamu compile pertama kali. Kalau ada error compiler,   |
//| kirim pesan errornya persis, saya bantu perbaiki.                  |
//+------------------------------------------------------------------+
#property copyright "didinska"
#property version   "1.00"
#property strict

#include <AiSignalEA/Common.mqh>
#include <AiSignalEA/JsonUtil.mqh>
#include <AiSignalEA/TelegramNotify.mqh>
#include <AiSignalEA/AiAnalyst.mqh>
#include <AiSignalEA/RiskEngineS1.mqh>
#include <AiSignalEA/RiskEngineS2.mqh>

enum ENUM_TRADE_MODE
{
   TRADE_MODE_SCALPING = 0,
   TRADE_MODE_DAYTRADE = 1,
   TRADE_MODE_SWING    = 2
};

input group "=== Groq AI ==="
input string InpGroqApiKey                 = "";                   // Groq API Key (wajib diisi)
input string InpGroqModel                  = "openai/gpt-oss-120b"; // Model Groq

input group "=== Telegram (notifikasi satu arah saja) ==="
input string InpTelegramBotToken           = "";                   // Bot Token (kosongkan buat nonaktifkan notifikasi)
input string InpTelegramChatId             = "";                   // Chat ID tujuan notifikasi

input group "=== Strategi & Jadwal ==="
input ENUM_AI_STRATEGY InpStrategy         = STRATEGY_S1_SINGLE;   // Pilih Strategi (1 instance EA = 1 strategi)
input ENUM_TRADE_MODE  InpTradeMode        = TRADE_MODE_SCALPING;  // Mode trading (konteks buat prompt AI)
input int              InpCycleIntervalSeconds = 600;              // Interval siklus analisa AI (detik, default 600 = 10 menit)

input group "=== Strategi 1: single position, native SL/TP, lot dinamis ==="
input int    InpMagicNumberS1              = 20260901;             // Magic Number S1
input double InpRiskSlPercent              = 1.0;                  // Risiko ke SL asli (% balance)
input double InpForceCloseProfitPercent    = 2.0;                  // Force-close tambahan: profit (% balance)
input double InpForceCloseLossPercent      = 1.0;                  // Force-close tambahan: loss (% balance)
input int    InpMaxTradesPerDay            = 5;                    // Limit trade per hari
input double InpMaxDailyLossPercent        = 3.0;                  // Circuit breaker rugi harian (%)

input group "=== Strategi 2: sampai N layer independen, market order murni ==="
input int    InpMagicNumberS2              = 20260902;             // Magic Number S2 (WAJIB beda dari S1)
input double InpLayerLot                   = 0.01;                 // Lot FIXED per layer
input int    InpMaxLayers                  = 10;                   // Maksimal layer bersamaan
input double InpLayerTpUsd                 = 2.0;                  // TP per layer, flat $ (BUKAN %)
input double InpLayerSlUsd                 = 1.0;                  // SL per layer, flat $ (BUKAN %)

input group "=== Keamanan ==="
input bool   InpRequireDemoAccount         = true;                 // Wajib akun DEMO (JANGAN matikan sembarangan)

#define TIMER_HEARTBEAT_SECONDS 5

int g_secondsSinceLastCycle = 0;

//+------------------------------------------------------------------+
string TradeModeToLabel(const ENUM_TRADE_MODE mode)
{
   switch (mode)
   {
      case TRADE_MODE_SCALPING: return "Scalping (jangka pendek)";
      case TRADE_MODE_DAYTRADE: return "Day Trade (intraday)";
      case TRADE_MODE_SWING:    return "Swing (jangka menengah-panjang)";
   }
   return "Scalping (jangka pendek)";
}

int ActiveMagicNumber() { return (InpStrategy == STRATEGY_S1_SINGLE) ? InpMagicNumberS1 : InpMagicNumberS2; }
string ActiveStrategyLabel() { return (InpStrategy == STRATEGY_S1_SINGLE) ? "Strategi 1 (single position)" : "Strategi 2 (multi-layer)"; }

//+------------------------------------------------------------------+
int OnInit()
{
   if (InpRequireDemoAccount && (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE) != ACCOUNT_TRADE_MODE_DEMO)
   {
      Alert("AiSignalEA: akun ini BUKAN akun demo, dan InpRequireDemoAccount=true. EA TIDAK akan jalan. Ganti setting ini HANYA kalau kamu benar-benar sadar risikonya.");
      return INIT_FAILED;
   }

   if (StringLen(InpGroqApiKey) == 0)
   {
      Alert("AiSignalEA: InpGroqApiKey masih kosong. Isi API key Groq dulu di Input Parameter EA.");
      return INIT_FAILED;
   }

   if (InpMagicNumberS1 == InpMagicNumberS2)
   {
      Alert("AiSignalEA: InpMagicNumberS1 dan InpMagicNumberS2 TIDAK BOLEH sama. Ganti salah satunya.");
      return INIT_FAILED;
   }

   if (_Symbol != "XAUUSD")
      PrintFormat("⚠️ EA ini didesain untuk XAUUSD, tapi dipasang di %s. Prompt AI & asumsi masih jalan, tapi belum ditujukan buat simbol ini.", _Symbol);

   g_secondsSinceLastCycle = InpCycleIntervalSeconds; // biar siklus analisa pertama langsung jalan, gak nunggu penuh interval dulu
   EventSetTimer(TIMER_HEARTBEAT_SECONDS);

   PrintFormat("🤖 AiSignalEA AKTIF -- %s, symbol=%s, magic=%d, interval siklus=%ds",
      ActiveStrategyLabel(), _Symbol, ActiveMagicNumber(), InpCycleIntervalSeconds);

   TelegramSend(InpTelegramBotToken, InpTelegramChatId,
      StringFormat("🤖 <b>AiSignalEA AKTIF</b>\n%s\nSymbol: %s | Magic: %d\nSiklus analisa tiap %d menit.",
         ActiveStrategyLabel(), _Symbol, ActiveMagicNumber(), InpCycleIntervalSeconds / 60));

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   PrintFormat("🛑 AiSignalEA berhenti (reason=%d).", reason);
   TelegramSend(InpTelegramBotToken, InpTelegramChatId,
      "🛑 <b>AiSignalEA DIHENTIKAN</b> (EA di-remove / chart ditutup / terminal mati). Posisi yang masih terbuka TIDAK otomatis ditutup oleh siapa pun sampai EA jalan lagi.");
}

//+------------------------------------------------------------------+
void OnTick()
{
   // Sengaja kosong -- semua logika berjalan lewat OnTimer(), bukan
   // tiap tick, biar frekuensinya konsisten & terkontrol (heartbeat
   // force-close tiap TIMER_HEARTBEAT_SECONDS, siklus AI tiap
   // InpCycleIntervalSeconds) terlepas dari seberapa ramai tick simbol.
}

//+------------------------------------------------------------------+
void OnTimer()
{
   int magicNumber = ActiveMagicNumber();

   // Force-close monitor jalan TIAP heartbeat (default 5 detik),
   // TERLEPAS dari siklus analisa AI yang jauh lebih jarang.
   if (InpStrategy == STRATEGY_S1_SINGLE)
      S1_CheckForceClose(magicNumber, InpForceCloseProfitPercent, InpForceCloseLossPercent, InpTelegramBotToken, InpTelegramChatId);
   else
      S2_CheckForceClose(magicNumber, InpLayerTpUsd, InpLayerSlUsd, InpTelegramBotToken, InpTelegramChatId);

   g_secondsSinceLastCycle += TIMER_HEARTBEAT_SECONDS;
   if (g_secondsSinceLastCycle >= InpCycleIntervalSeconds)
   {
      g_secondsSinceLastCycle = 0;
      RunAnalysisCycle();
   }
}

//+------------------------------------------------------------------+
//| 1 siklus penuh: cek guardrail -> (kalau lolos) panggil AI -> parse |
//| -> eksekusi sesuai strategi aktif. Guardrail dicek PALING AWAL,    |
//| SEBELUM panggil AI sama sekali, biar hemat biaya API Groq kalau    |
//| toh sinyal barunya bakal ditolak juga (posisi masih ada / limit    |
//| harian / layer penuh).                                             |
//+------------------------------------------------------------------+
void RunAnalysisCycle()
{
   int magicNumber = ActiveMagicNumber();
   string reason = "";
   bool allowed;

   if (InpStrategy == STRATEGY_S1_SINGLE)
      allowed = S1_CheckGuardrails(magicNumber, InpMaxTradesPerDay, InpMaxDailyLossPercent, reason);
   else
      allowed = S2_CheckGuardrails(magicNumber, InpMaxLayers, reason);

   if (!allowed)
   {
      PrintFormat("⏭️ Siklus di-skip (tanpa panggil AI): %s", reason);
      return;
   }

   SAiDecision decision = RequestAiDecision(InpGroqApiKey, InpGroqModel, _Symbol, TradeModeToLabel(InpTradeMode));

   if (!decision.success)
   {
      PrintFormat("⚠️ Gagal ambil keputusan AI: %s", decision.rawError);
      return; // JANGAN eksekusi apa pun kalau AI gagal / jawaban tidak valid
   }

   PrintFormat("📊 AI: %s (confidence=%.0f%%) -- %s", decision.decision, decision.confidence, decision.reasoning);

   if (decision.decision == "WAIT")
      return; // tidak notif Telegram tiap WAIT, biar gak spam tiap siklus -- cukup log

   TelegramSend(InpTelegramBotToken, InpTelegramChatId,
      StringFormat("📊 <b>Sinyal %s</b> (confidence %.0f%%)\n%s", decision.decision, decision.confidence, decision.reasoning));

   if (InpStrategy == STRATEGY_S1_SINGLE)
      S1_ExecuteTrade(decision.decision, decision.entry, decision.sl, decision.tp, magicNumber, InpRiskSlPercent, InpTelegramBotToken, InpTelegramChatId);
   else
      S2_ExecuteLayer(decision.decision, InpLayerLot, magicNumber, InpMaxLayers, InpTelegramBotToken, InpTelegramChatId);
}
